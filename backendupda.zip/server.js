require("dotenv").config()

const express = require("express")
const cors = require("cors")
const mongoose = require("mongoose")


const app = express()

app.use(cors())
app.use(express.json())

mongoose.connect(process.env.MONGO_URI)
.then(()=>console.log("MongoDB Connected"))
.catch(err=>console.log(err))

const authRoutes = require("./routes/authRoutes");
const ticketRoutes = require("./routes/ticketRoutes");
const adminRoutes = require("./routes/adminRoutes");

app.use("/api/auth", authRoutes);
app.use("/api/tickets", ticketRoutes);
app.use("/api/admin", adminRoutes);





app.get("/",(req,res)=>{
res.send("Helpdesk API running")
})

const PORT = process.env.PORT || 8000

app.listen(PORT,()=>{
console.log(`Server running on ${PORT}`)
})