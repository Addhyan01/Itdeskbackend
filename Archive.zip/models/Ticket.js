const mongoose = require("mongoose");

const auditLogSchema = new mongoose.Schema({
  action: { type: String, required: true },
  performedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  performedByName: { type: String },
  note: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now }
});

const commentSchema = new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  authorName: { type: String },
  authorRole: { type: String },
  text: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

const ticketSchema = new mongoose.Schema(
  {
    ticketId: { type: String, unique: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    category: {
      type: String,
      enum: ["Hardware", "Software", "Network", "Account", "Other"],
      default: "Other",
    },
    priority: {
      type: String,
      enum: ["Low", "Medium", "High", "Critical"],
      default: "Medium",
    },
    status: {
      type: String,
      enum: ["Pending", "In Process", "Working", "Resolved", "Closed"],
      default: "Pending",
    },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    
    // Due date - admin/tech set kar sakte hain
    dueDate: { type: Date, default: null },
    
    // Auto close tracking
    resolvedAt: { type: Date, default: null },
    closedAt: { type: Date, default: null },
    
    // Attachments
    attachments: [{ url: String, filename: String }],
    
    // Comments - user, admin, technician sab kar sakte hain
    comments: [commentSchema],
    
    // Audit Log - har action record hoga
    auditLog: [auditLogSchema],
  },
  { timestamps: true }
);

// Auto-generate ticketId
ticketSchema.pre("save", async function (next) {
  if (!this.ticketId) {
    const count = await mongoose.model("Ticket").countDocuments();
    this.ticketId = `TKT-${String(count + 1).padStart(5, "0")}`;
  }
  next();
});

// SLA hours based on priority
ticketSchema.methods.getSLAHours = function () {
  const sla = { Critical: 4, High: 24, Medium: 48, Low: 72 };
  return sla[this.priority] || 48;
};

// SLA status - green/yellow/red
ticketSchema.methods.getSLAStatus = function () {
  if (["Resolved", "Closed"].includes(this.status)) return "completed";
  const slaHours = this.getSLAHours();
  const hoursElapsed = (Date.now() - this.createdAt) / (1000 * 60 * 60);
  const percentage = (hoursElapsed / slaHours) * 100;
  if (percentage < 50) return "green";
  if (percentage < 80) return "yellow";
  return "red";
};

module.exports = mongoose.model("Ticket", ticketSchema);
